import "./App.css";
import React, { useEffect, useState } from "react";
import { DateTime } from "luxon";
import ClockSynchronizer from "./ClockSynchronizer";

function Clock() {
  const [currentTime, setCurrentTime] = useState(null);
  const [error, setCurrentError] = useState(null);

  useEffect(() => {
    if (currentTime) {
      const timer = setInterval(() => {
        console.log("Tick");
        setCurrentTime((currTime) => currTime.plus(1000));
      }, 1000);
      return () => {
        clearInterval(timer);
      };
    }
  }, [currentTime]);

  const handleSyncClock = React.useCallback((milisecond) => {
    setCurrentTime((currTime) => {
      if (currTime)
        console.log(
          `calibrated ${Math.abs(currTime.toMillis() - milisecond)} miliseconds`
        );

      return DateTime.fromMillis(milisecond);
    });
  }, []);

  const handleSynchronizerError = React.useCallback((error) => {
    setCurrentError(error);
  }, []);

  const renderContent = () => {
    if (currentTime) {
      return currentTime.toLocaleString(DateTime.DATETIME_MED_WITH_SECONDS);
    } else if (error) {
      return "An error has occurred: " + error.message;
    } else {
      return "Loading...";
    }
  };

  return (
    <>
      <div>{renderContent()}</div>
      <ClockSynchronizer
        onSync={handleSyncClock}
        onError={handleSynchronizerError}
      />
    </>
  );
}

export default Clock;
