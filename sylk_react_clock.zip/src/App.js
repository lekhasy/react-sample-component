import "./App.css";
import React, { useState } from "react";
import Clock from "./Clock";

function App() {
  const [mount, setMount] = useState(true);

  return (
    <>
      {mount ? <Clock /> : null}
      <button onClick={() => setMount((m) => !m)}>Toggle Mount</button>
    </>
  );
}

export default App;
