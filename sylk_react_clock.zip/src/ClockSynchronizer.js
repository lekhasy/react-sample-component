import React from "react";
import { useQuery } from "react-query";

export default React.memo(function ClockSynchronizer({ onSync, onError }) {
  console.log("Synchronizer re-render");
  useQuery(
    "serverTime",
    () =>
      fetch("http://worldtimeapi.org/api/timezone/Asia/Bangkok").then((res) =>
        res.json()
      ),
    {
      // Calibrate the clock every 5 seconds
      refetchInterval: 10000,
      notifyOnChangeProps: [],
      onError: (err) => {
        onError(err);
      },
      onSuccess: (data) => {
        onSync(data.unixtime * 1000);
      },
    }
  );

  return null;
});
